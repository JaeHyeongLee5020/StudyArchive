from tkinter import *
from tkinter.filedialog import *
from tkinter.simpledialog import *
from PIL import Image, ImageFilter, ImageEnhance, ImageOps, ImageTk

def display_photo(img, height, width):
    global root, canvas, inPhoto, outPhoto, inX, inY, photo_img
    if canvas is not None:
        canvas.destroy()
    root.geometry(str(height) + "x" + str(width))
    photo_img = ImageTk.PhotoImage(img)

    canvas = Canvas(root, width=height, height=width)
    canvas.create_image(0, 0, anchor=NW, image=photo_img)
    canvas.pack()

def update_status_bar():
    global inPhoto, outPhoto, inX, inY, outX, outY
    status_bar.config(text=f"Input Image: {inX}x{inY}, Output Image: {outX}x{outY}")

def add_to_history(photo):
    history.append(photo.copy())

def undo():
    global outPhoto
    if len(history) > 1:
        redo_history.append(history.pop().copy())
        outPhoto = history[-1].copy()
        display_photo(outPhoto, outPhoto.width, outPhoto.height)
        update_status_bar()

def redo():
    global outPhoto
    if redo_history:
        history.append(redo_history.pop().copy())
        outPhoto = history[-1].copy()
        display_photo(outPhoto, outPhoto.width, outPhoto.height)
        update_status_bar()

def manage_history():
    add_to_history(outPhoto)
    redo_history.clear()
    if len(history) > 10:
        history.pop(0)

def func_open(event=None):
    global root, inPhoto, outPhoto, inX, inY, outX, outY, photo_img
    filename = askopenfilename(parent=root, filetypes=(("All Image Files", "*.jpg;*.jpeg;*.bmp;*.png;*.tif"), ("All Files", "*.*")))
    if filename:
        inPhoto = Image.open(filename)
        inX, inY = inPhoto.width, inPhoto.height
        outPhoto = inPhoto.copy()
        outX, outY = outPhoto.width, outPhoto.height
        manage_history()
        display_photo(outPhoto, outX, outY)
        update_status_bar()

def func_save(event=None):
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    if outPhoto is not None:
        save_filename = asksaveasfilename(defaultextension=".png", filetypes=(("PNG File", "*.png"), ("All Files", "*.*")))
        if save_filename:
            outPhoto.save(save_filename)
            manage_history()

def func_zoomin():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    scale = askinteger("Zoom In", "Enter the zoom factor (2-8):", minvalue=2, maxvalue=8)
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.resize((int(inX * scale), int(inY * scale)))
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_zoomout():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    scale = askinteger("Zoom Out", "Enter the zoom factor (2-8):", minvalue=2, maxvalue=8)
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.resize((int(inX / scale), int(inY / scale)))
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_mirror1():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.transpose(Image.FLIP_TOP_BOTTOM)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_mirror2():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.transpose(Image.FLIP_LEFT_RIGHT)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_rotate():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    degree = askinteger("Rotate", "Enter the rotation angle (0-360):", minvalue=0, maxvalue=360)
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.rotate(degree, expand=True)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_bright():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    value = askfloat("Brightness", "Enter the brightness value (0.0-5.0):", minvalue=0.0, maxvalue=5.0)
    outPhoto = inPhoto.copy()
    outPhoto = ImageEnhance.Brightness(outPhoto).enhance(value)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_embos():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.filter(ImageFilter.EMBOSS)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_blur():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = inPhoto
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.filter(ImageFilter.BLUR)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_sketch():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.filter(ImageFilter.CONTOUR)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_contour():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = inPhoto.copy()
    outPhoto = outPhoto.filter(ImageFilter.FIND_EDGES)
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_grayscale():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = inPhoto.copy().convert('L')  
    outX, outY = outPhoto.width, outPhoto.height
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_invert_color():
    global root, inPhoto, outPhoto, inX, inY, outX, outY
    outPhoto = ImageOps.invert(inPhoto)
    manage_history()
    display_photo(outPhoto, outX, outY)
    update_status_bar()

def func_intro():
    messagebox.showinfo('Introduction', 'Pillow 라이브러리 테스')

def func_author():
    messagebox.showinfo('Author', 'Jang An Dae\n\n20192158 이재')

root, canvas = None, None
inPhoto, outPhoto = None, None
inX, inY, outX, outY = 0, 0, 0, 0
history = []
redo_history = []
photo_img = None

root = Tk()
root.geometry("500x500")
root.title("Photo Editor")

mainMenu = Menu(root)
root.config(menu=mainMenu)

fileMenu = Menu(mainMenu)
mainMenu.add_cascade(label="File", menu=fileMenu)
fileMenu.add_command(label="Open File", command=func_open)
fileMenu.add_command(label="Save File", command=func_save)
fileMenu.add_separator()
fileMenu.add_command(label="Exit", command=func_exit)

editMenu = Menu(mainMenu)
mainMenu.add_cascade(label="Undo", menu=editMenu)
editMenu.add_command(label="Undo", command=undo)
editMenu.add_command(label="Redo", command=redo)

effect1Menu = Menu(mainMenu)
mainMenu.add_cascade(label="Image Processing (1)", menu=effect1Menu)
effect1Menu.add_command(label="Zoom In", command=func_zoomin)
effect1Menu.add_command(label="Zoom Out", command=func_zoomout)
effect1Menu.add_separator()
effect1Menu.add_command(label="Flip Vertically", command=func_mirror1)
effect1Menu.add_command(label="Flip Horizontally", command=func_mirror2)
effect1Menu.add_command(label="Rotate", command=func_rotate)

effect2Menu = Menu(mainMenu)
mainMenu.add_cascade(label="Image Processing (2)", menu=effect2Menu)
effect2Menu.add_command(label="Brightness", command=func_bright)
effect2Menu.add_separator()
effect2Menu.add_command(label="Emboss", command=func_embos)
effect2Menu.add_command(label="Blur", command=func_blur)
effect2Menu.add_separator()
effect2Menu.add_command(label="Pencil Sketch", command=func_sketch)
effect2Menu.add_command(label="Edge Detection", command=func_contour)
effect2Menu.add_separator()
effect2Menu.add_command(label="Grayscale", command=func_grayscale)
effect2Menu.add_command(label="Invert Color", command=func_invert_color)

introMenu = Menu(mainMenu)
mainMenu.add_cascade(label='Information', menu=introMenu)
introMenu.add_command(label='Program Introduction', command=func_intro)
introMenu.add_separator()
introMenu.add_command(label='Author Introduction', command=func_author)

status_bar = Label(root, text="", bd=1, relief=SUNKEN, anchor=W)
status_bar.pack(side=BOTTOM, fill=X)

root.bind("<Control-z>", lambda event: undo())
root.bind("<Control-y>", lambda event: redo())
root.bind("<Control-s>", lambda event: func_save(event))  
root.bind("<Shift-O>", lambda event: func_open(event)) 

root.mainloop()





