장안대학교 소프트웨어 2학년 A반 20192158 이재형 기말 실습파일 입니다.

 제가 사용하는 환경이 맥os(실리콘) 밖에 없어서 실제로 잘 구동 되는지 테스트를 해보지 못했습니다,,,, 참고해주시면 감사하겠습니다. ㅠ 한 학기동안 수고 많으셨습니다!

-파일 메뉴

Open File: 이미지 파일을 열어서 편집할 이미지를 선택합니다.
Save File: 현재 편집한 이미지를 저장합니다.
Exit: 프로그램을 종료합니다.


-편집 메뉴

Undo: 이전에 수행한 편집을 취소합니다.
Redo: Undo로 취소한 작업을 다시 실행합니다.


-이미지 처리 메뉴

Zoom In: 이미지를 확대합니다.
Zoom Out: 이미지를 축소합니다.
Flip Vertically: 이미지를 상하로 뒤집습니다.
Flip Horizontally: 이미지를 좌우로 뒤집습니다.
Rotate: 이미지를 주어진 각도만큼 회전시킵니다.


-이미지 처리 두번째 메뉴

Brightness: 이미지의 밝기를 조절합니다.
Emboss: 이미지를 Emboss 효과로 처리합니다.
Blur: 이미지에 블러 효과를 적용합니다.
Pencil Sketch: 이미지를 연필 스케치로 변환합니다.
Edge Detection: 이미지의 가장자리를 감지합니다.
Grayscale: 이미지를 흑백으로 변환합니다.
Invert Color: 이미지의 색상을 반전시킵니다.


-정보 메뉴

Program Introduction: 프로그램 소개 대화상자를 표시합니다.
Author Introduction: 프로그램 저자 소개 대화상자를 표시합니다.



